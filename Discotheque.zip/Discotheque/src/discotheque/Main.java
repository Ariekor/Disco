/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package discotheque;

/**
 *
 * @author Simon
 */
public class Main {
    
     public static void main(String[] args) {
      // cette classe appelle la fênetre d'identifition.
      
       Identifier fenetrePrincipale = new Identifier();
        fenetrePrincipale.setVisible(true);
      // TODO code application logic here
   }
}
